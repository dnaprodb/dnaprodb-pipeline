Testing can be performed from the parent directory via the following command:

```
$ python -m pytest
```

Note that some tests are very long and can take hours to complete.
