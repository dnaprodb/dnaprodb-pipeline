=============
:mod:`config`
=============

.. automodule:: pdb2pqr.config
   :members:
   :undoc-members:
