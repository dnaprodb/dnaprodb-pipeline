"""PDB2PQR Version number.
Store the version here so:

* we don't load dependencies by storing it in :file:`__init__.py`
* we can import it in setup.py for the same reason
* we can import it into your module
"""
__version__ = "3.5.2"
