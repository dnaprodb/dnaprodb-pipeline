![Python package](https://github.com/Electrostatics/pdb2pqr/workflows/Python%20package/badge.svg)
[![codecov](https://codecov.io/gh/Electrostatics/pdb2pqr/branch/master/graph/badge.svg)](https://codecov.io/gh/Electrostatics/pdb2pqr)
[![Documentation Status](https://readthedocs.org/projects/pdb2pqr/badge/?version=latest)](https://pdb2pqr.readthedocs.io/en/latest/?badge=latest)

PDB2PQR
============

This package contains the PDB2PQR software.  For more information, please see

* Home page:  http://www.poissonboltzmann.org/
* Documentation: http://pdb2pqr.readthedocs.io

